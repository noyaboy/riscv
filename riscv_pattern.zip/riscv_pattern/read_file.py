f = open("riscv.txt", "r")
# print(f.read())

for line in f:
    line = line.partition('//')[0]
    line = line.rstrip()
    
    print(line)